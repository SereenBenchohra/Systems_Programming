#ifndef ORDER_H
#define ORDER_H

void swap(int *a, int *b);
void orderTwo(int *a, int *b);
void orderThree(int *a, int *b, int *c);

#endif
