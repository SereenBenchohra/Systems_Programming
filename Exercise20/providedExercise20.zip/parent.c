int main(int argc, char **argv)
{
   /* Deal with the arguments */

   /* Create two pipes for two-way communication between parent and child */
   
   /* Create the child process - fork */

   /* Check for fork errors*/

   /* STYLE CHECK WILL FAIL THIS COMMENT BLOCK - One liners when you are done!
    *
    * Handle the CHILD process after the fork:
    *   * You can write the code in an if-else block here in main OR in a
    *     separate function or functions, as you prefer.
    *   * Some helper functions strongly suggested for clarity/comprehension!
    *   * Manage file descriptors - child inherits two pipes, four fds, but
    *     only going to know about and use two of them!
    *   * Call exec - remember arguments must be strings, fds are ints,
    *     sprintf might be helpful here!
    *   * Handle an exec failure - perror and exit to terminate child process!
    */

   /* STYLE CHECK WILL FAIL THIS COMMENT BLOCK - One liners when you are done!
    *
    * Handle the PARENT process after the fork:
    *   * You can write the code in an if-else block here in main OR in a
    *     separate function or functions, as you prefer.
    *   * Some helper functions strongly suggested for clarity/comprehension!
    *   * Manage file descriptors - parent has two pipes, four fds, but only
    *     going to use two of them. DON'T close them before the fork or the
    *     child process will inherit them as closed!
    *   * Read and print the "birth announcement" from the child
    *   * Enter the main parent-child dialog loop until "Goodnight Moon"
    *   * Close the write end of the pipe to child so that the child gets EOF
    *   * Read and print the last message from the child
    *   * Wait (man 2 wait) for the child to terminate (NOT in the dialog loop!)
    *   * Write final message
    *   * Done!
    */    

    return 0;
}
