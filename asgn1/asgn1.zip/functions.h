#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void translate(char set1[], char set2[]);
void delete_complement(char set1[]);
void my_delete(char set1[]);

#endif