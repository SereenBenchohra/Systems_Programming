#ifndef IN_READER_H
#define IN_READER_H

char *read_word(FILE *file);

#endif
