#ifndef QSORT_H
#define QSORT_H

int comparator(const void *node1p, const void *node2p);

#endif
